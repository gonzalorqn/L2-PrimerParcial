﻿public enum EComercio
{
    Importador,
    Exportador,
    Ambos
}